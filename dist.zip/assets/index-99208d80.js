import{a as e}from"./index-eef5c986.js";function s(r){return e}export{s as c};
