import{a as s,d as e,C as a}from"./Box-807d7112.js";const o=s("MuiBox",["root"]),t=o,r=e({defaultClassName:t.root,generateClassName:a.generate}),n=r;export{n as B};
