const s="/assets/user-1-6d05e3ce.jpg";export{s as u};
