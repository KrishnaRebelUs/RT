import{r as s,e as A,_ as X,b as oe,j as S,k as se,a as Te}from"./index-eef5c986.js";import{c as x,a as Me,s as ae,g as Ae,u as he,b as Xe}from"./Box-807d7112.js";const Ye=typeof window<"u"?s.useLayoutEffect:s.useEffect,We=Ye;function H(e){const t=s.useRef(e);return We(()=>{t.current=e}),s.useRef((...n)=>(0,t.current)(...n)).current}const me={};function He(e,t){const n=s.useRef(me);return n.current===me&&(n.current=e(t)),n}const Ge=[];function qe(e){s.useEffect(e,Ge)}class G{constructor(){this.currentId=null,this.clear=()=>{this.currentId!==null&&(clearTimeout(this.currentId),this.currentId=null)},this.disposeEffect=()=>this.clear}static create(){return new G}start(t,n){this.clear(),this.currentId=setTimeout(()=>{this.currentId=null,n()},t)}}function Ze(){const e=He(G.create).current;return qe(e.disposeEffect),e}let q=!0,ne=!1;const Je=new G,Qe={text:!0,search:!0,url:!0,tel:!0,email:!0,password:!0,number:!0,date:!0,month:!0,week:!0,time:!0,datetime:!0,"datetime-local":!0};function et(e){const{type:t,tagName:n}=e;return!!(n==="INPUT"&&Qe[t]&&!e.readOnly||n==="TEXTAREA"&&!e.readOnly||e.isContentEditable)}function tt(e){e.metaKey||e.altKey||e.ctrlKey||(q=!0)}function te(){q=!1}function nt(){this.visibilityState==="hidden"&&ne&&(q=!0)}function rt(e){e.addEventListener("keydown",tt,!0),e.addEventListener("mousedown",te,!0),e.addEventListener("pointerdown",te,!0),e.addEventListener("touchstart",te,!0),e.addEventListener("visibilitychange",nt,!0)}function it(e){const{target:t}=e;try{return t.matches(":focus-visible")}catch{}return q||et(t)}function ot(){const e=s.useCallback(r=>{r!=null&&rt(r.ownerDocument)},[]),t=s.useRef(!1);function n(){return t.current?(ne=!0,Je.start(100,()=>{ne=!1}),t.current=!1,!0):!1}function u(r){return it(r)?(t.current=!0,!0):!1}return{isFocusVisibleRef:t,onFocus:u,onBlur:n,ref:e}}function re(e,t){return re=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(u,r){return u.__proto__=r,u},re(e,t)}function st(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,re(e,t)}const be=A.createContext(null);function at(e){if(e===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}function ue(e,t){var n=function(i){return t&&s.isValidElement(i)?t(i):i},u=Object.create(null);return e&&s.Children.map(e,function(r){return r}).forEach(function(r){u[r.key]=n(r)}),u}function ut(e,t){e=e||{},t=t||{};function n(d){return d in t?t[d]:e[d]}var u=Object.create(null),r=[];for(var i in e)i in t?r.length&&(u[i]=r,r=[]):r.push(i);var o,c={};for(var l in t){if(u[l])for(o=0;o<u[l].length;o++){var p=u[l][o];c[u[l][o]]=n(p)}c[l]=n(l)}for(o=0;o<r.length;o++)c[r[o]]=n(r[o]);return c}function F(e,t,n){return n[t]!=null?n[t]:e.props[t]}function lt(e,t){return ue(e.children,function(n){return s.cloneElement(n,{onExited:t.bind(null,n),in:!0,appear:F(n,"appear",e),enter:F(n,"enter",e),exit:F(n,"exit",e)})})}function ct(e,t,n){var u=ue(e.children),r=ut(t,u);return Object.keys(r).forEach(function(i){var o=r[i];if(s.isValidElement(o)){var c=i in t,l=i in u,p=t[i],d=s.isValidElement(p)&&!p.props.in;l&&(!c||d)?r[i]=s.cloneElement(o,{onExited:n.bind(null,o),in:!0,exit:F(o,"exit",e),enter:F(o,"enter",e)}):!l&&c&&!d?r[i]=s.cloneElement(o,{in:!1}):l&&c&&s.isValidElement(p)&&(r[i]=s.cloneElement(o,{onExited:n.bind(null,o),in:p.props.in,exit:F(o,"exit",e),enter:F(o,"enter",e)}))}}),r}var pt=Object.values||function(e){return Object.keys(e).map(function(t){return e[t]})},ft={component:"div",childFactory:function(t){return t}},le=function(e){st(t,e);function t(u,r){var i;i=e.call(this,u,r)||this;var o=i.handleExited.bind(at(i));return i.state={contextValue:{isMounting:!0},handleExited:o,firstRender:!0},i}var n=t.prototype;return n.componentDidMount=function(){this.mounted=!0,this.setState({contextValue:{isMounting:!1}})},n.componentWillUnmount=function(){this.mounted=!1},t.getDerivedStateFromProps=function(r,i){var o=i.children,c=i.handleExited,l=i.firstRender;return{children:l?lt(r,c):ct(r,o,c),firstRender:!1}},n.handleExited=function(r,i){var o=ue(this.props.children);r.key in o||(r.props.onExited&&r.props.onExited(i),this.mounted&&this.setState(function(c){var l=X({},c.children);return delete l[r.key],{children:l}}))},n.render=function(){var r=this.props,i=r.component,o=r.childFactory,c=oe(r,["component","childFactory"]),l=this.state.contextValue,p=pt(this.state.children).map(o);return delete c.appear,delete c.enter,delete c.exit,i===null?A.createElement(be.Provider,{value:l},p):A.createElement(be.Provider,{value:l},A.createElement(i,c,p))},t}(A.Component);le.propTypes={};le.defaultProps=ft;const dt=le;function ht(e){const{className:t,classes:n,pulsate:u=!1,rippleX:r,rippleY:i,rippleSize:o,in:c,onExited:l,timeout:p}=e,[d,g]=s.useState(!1),b=x(t,n.ripple,n.rippleVisible,u&&n.ripplePulsate),C={width:o,height:o,top:-(o/2)+i,left:-(o/2)+r},h=x(n.child,d&&n.childLeaving,u&&n.childPulsate);return!c&&!d&&g(!0),s.useEffect(()=>{if(!c&&l!=null){const y=setTimeout(l,p);return()=>{clearTimeout(y)}}},[l,c,p]),S.jsx("span",{className:b,style:C,children:S.jsx("span",{className:h})})}const mt=Me("MuiTouchRipple",["root","ripple","rippleVisible","ripplePulsate","child","childLeaving","childPulsate"]),m=mt,bt=["center","classes","className"];let Z=e=>e,ge,ye,Re,Ee;const ie=550,gt=80,yt=se(ge||(ge=Z`
  0% {
    transform: scale(0);
    opacity: 0.1;
  }

  100% {
    transform: scale(1);
    opacity: 0.3;
  }
`)),Rt=se(ye||(ye=Z`
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }
`)),Et=se(Re||(Re=Z`
  0% {
    transform: scale(1);
  }

  50% {
    transform: scale(0.92);
  }

  100% {
    transform: scale(1);
  }
`)),Tt=ae("span",{name:"MuiTouchRipple",slot:"Root"})({overflow:"hidden",pointerEvents:"none",position:"absolute",zIndex:0,top:0,right:0,bottom:0,left:0,borderRadius:"inherit"}),Mt=ae(ht,{name:"MuiTouchRipple",slot:"Ripple"})(Ee||(Ee=Z`
  opacity: 0;
  position: absolute;

  &.${0} {
    opacity: 0.3;
    transform: scale(1);
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  &.${0} {
    animation-duration: ${0}ms;
  }

  & .${0} {
    opacity: 1;
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: currentColor;
  }

  & .${0} {
    opacity: 0;
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  & .${0} {
    position: absolute;
    /* @noflip */
    left: 0px;
    top: 0;
    animation-name: ${0};
    animation-duration: 2500ms;
    animation-timing-function: ${0};
    animation-iteration-count: infinite;
    animation-delay: 200ms;
  }
`),m.rippleVisible,yt,ie,({theme:e})=>e.transitions.easing.easeInOut,m.ripplePulsate,({theme:e})=>e.transitions.duration.shorter,m.child,m.childLeaving,Rt,ie,({theme:e})=>e.transitions.easing.easeInOut,m.childPulsate,Et,({theme:e})=>e.transitions.easing.easeInOut),xt=s.forwardRef(function(t,n){const u=Te({props:t,name:"MuiTouchRipple"}),{center:r=!1,classes:i={},className:o}=u,c=oe(u,bt),[l,p]=s.useState([]),d=s.useRef(0),g=s.useRef(null);s.useEffect(()=>{g.current&&(g.current(),g.current=null)},[l]);const b=s.useRef(!1),C=Ze(),h=s.useRef(null),y=s.useRef(null),O=s.useCallback(f=>{const{pulsate:R,rippleX:E,rippleY:D,rippleSize:j,cb:U}=f;p(T=>[...T,S.jsx(Mt,{classes:{ripple:x(i.ripple,m.ripple),rippleVisible:x(i.rippleVisible,m.rippleVisible),ripplePulsate:x(i.ripplePulsate,m.ripplePulsate),child:x(i.child,m.child),childLeaving:x(i.childLeaving,m.childLeaving),childPulsate:x(i.childPulsate,m.childPulsate)},timeout:ie,pulsate:R,rippleX:E,rippleY:D,rippleSize:j},d.current)]),d.current+=1,g.current=U},[i]),N=s.useCallback((f={},R={},E=()=>{})=>{const{pulsate:D=!1,center:j=r||R.pulsate,fakeElement:U=!1}=R;if((f==null?void 0:f.type)==="mousedown"&&b.current){b.current=!1;return}(f==null?void 0:f.type)==="touchstart"&&(b.current=!0);const T=U?null:y.current,P=T?T.getBoundingClientRect():{width:0,height:0,left:0,top:0};let v,B,L;if(j||f===void 0||f.clientX===0&&f.clientY===0||!f.clientX&&!f.touches)v=Math.round(P.width/2),B=Math.round(P.height/2);else{const{clientX:I,clientY:V}=f.touches&&f.touches.length>0?f.touches[0]:f;v=Math.round(I-P.left),B=Math.round(V-P.top)}if(j)L=Math.sqrt((2*P.width**2+P.height**2)/3),L%2===0&&(L+=1);else{const I=Math.max(Math.abs((T?T.clientWidth:0)-v),v)*2+2,V=Math.max(Math.abs((T?T.clientHeight:0)-B),B)*2+2;L=Math.sqrt(I**2+V**2)}f!=null&&f.touches?h.current===null&&(h.current=()=>{O({pulsate:D,rippleX:v,rippleY:B,rippleSize:L,cb:E})},C.start(gt,()=>{h.current&&(h.current(),h.current=null)})):O({pulsate:D,rippleX:v,rippleY:B,rippleSize:L,cb:E})},[r,O,C]),_=s.useCallback(()=>{N({},{pulsate:!0})},[N]),$=s.useCallback((f,R)=>{if(C.clear(),(f==null?void 0:f.type)==="touchend"&&h.current){h.current(),h.current=null,C.start(0,()=>{$(f,R)});return}h.current=null,p(E=>E.length>0?E.slice(1):E),g.current=R},[C]);return s.useImperativeHandle(n,()=>({pulsate:_,start:N,stop:$}),[_,N,$]),S.jsx(Tt,X({className:x(m.root,i.root,o),ref:y},c,{children:S.jsx(dt,{component:null,exit:!0,children:l})}))}),Ct=xt;function vt(e){return Ae("MuiButtonBase",e)}const Vt=Me("MuiButtonBase",["root","disabled","focusVisible"]),wt=Vt,Pt=["action","centerRipple","children","className","component","disabled","disableRipple","disableTouchRipple","focusRipple","focusVisibleClassName","LinkComponent","onBlur","onClick","onContextMenu","onDragLeave","onFocus","onFocusVisible","onKeyDown","onKeyUp","onMouseDown","onMouseLeave","onMouseUp","onTouchEnd","onTouchMove","onTouchStart","tabIndex","TouchRippleProps","touchRippleRef","type"],Bt=e=>{const{disabled:t,focusVisible:n,focusVisibleClassName:u,classes:r}=e,o=Xe({root:["root",t&&"disabled",n&&"focusVisible"]},vt,r);return n&&u&&(o.root+=` ${u}`),o},Lt=ae("button",{name:"MuiButtonBase",slot:"Root",overridesResolver:(e,t)=>t.root})({display:"inline-flex",alignItems:"center",justifyContent:"center",position:"relative",boxSizing:"border-box",WebkitTapHighlightColor:"transparent",backgroundColor:"transparent",outline:0,border:0,margin:0,borderRadius:0,padding:0,cursor:"pointer",userSelect:"none",verticalAlign:"middle",MozAppearance:"none",WebkitAppearance:"none",textDecoration:"none",color:"inherit","&::-moz-focus-inner":{borderStyle:"none"},[`&.${wt.disabled}`]:{pointerEvents:"none",cursor:"default"},"@media print":{colorAdjust:"exact"}}),Dt=s.forwardRef(function(t,n){const u=Te({props:t,name:"MuiButtonBase"}),{action:r,centerRipple:i=!1,children:o,className:c,component:l="button",disabled:p=!1,disableRipple:d=!1,disableTouchRipple:g=!1,focusRipple:b=!1,LinkComponent:C="a",onBlur:h,onClick:y,onContextMenu:O,onDragLeave:N,onFocus:_,onFocusVisible:$,onKeyDown:f,onKeyUp:R,onMouseDown:E,onMouseLeave:D,onMouseUp:j,onTouchEnd:U,onTouchMove:T,onTouchStart:P,tabIndex:v=0,TouchRippleProps:B,touchRippleRef:L,type:I}=u,V=oe(u,Pt),K=s.useRef(null),M=s.useRef(null),xe=he(M,L),{isFocusVisibleRef:ce,onFocus:Ce,onBlur:ve,ref:Ve}=ot(),[k,Y]=s.useState(!1);p&&k&&Y(!1),s.useImperativeHandle(r,()=>({focusVisible:()=>{Y(!0),K.current.focus()}}),[]);const[J,we]=s.useState(!1);s.useEffect(()=>{we(!0)},[]);const Pe=J&&!d&&!p;s.useEffect(()=>{k&&b&&!d&&J&&M.current.pulsate()},[d,b,k,J]);function w(a,fe,ze=g){return H(de=>(fe&&fe(de),!ze&&M.current&&M.current[a](de),!0))}const Be=w("start",E),Le=w("stop",O),De=w("stop",N),Ie=w("stop",j),ke=w("stop",a=>{k&&a.preventDefault(),D&&D(a)}),Fe=w("start",P),Se=w("stop",U),Ne=w("stop",T),$e=w("stop",a=>{ve(a),ce.current===!1&&Y(!1),h&&h(a)},!1),je=H(a=>{K.current||(K.current=a.currentTarget),Ce(a),ce.current===!0&&(Y(!0),$&&$(a)),_&&_(a)}),Q=()=>{const a=K.current;return l&&l!=="button"&&!(a.tagName==="A"&&a.href)},ee=s.useRef(!1),Oe=H(a=>{b&&!ee.current&&k&&M.current&&a.key===" "&&(ee.current=!0,M.current.stop(a,()=>{M.current.start(a)})),a.target===a.currentTarget&&Q()&&a.key===" "&&a.preventDefault(),f&&f(a),a.target===a.currentTarget&&Q()&&a.key==="Enter"&&!p&&(a.preventDefault(),y&&y(a))}),_e=H(a=>{b&&a.key===" "&&M.current&&k&&!a.defaultPrevented&&(ee.current=!1,M.current.stop(a,()=>{M.current.pulsate(a)})),R&&R(a),y&&a.target===a.currentTarget&&Q()&&a.key===" "&&!a.defaultPrevented&&y(a)});let W=l;W==="button"&&(V.href||V.to)&&(W=C);const z={};W==="button"?(z.type=I===void 0?"button":I,z.disabled=p):(!V.href&&!V.to&&(z.role="button"),p&&(z["aria-disabled"]=p));const Ue=he(n,Ve,K),pe=X({},u,{centerRipple:i,component:l,disabled:p,disableRipple:d,disableTouchRipple:g,focusRipple:b,tabIndex:v,focusVisible:k}),Ke=Bt(pe);return S.jsxs(Lt,X({as:W,className:x(Ke.root,c),ownerState:pe,onBlur:$e,onClick:y,onContextMenu:Le,onFocus:je,onKeyDown:Oe,onKeyUp:_e,onMouseDown:Be,onMouseLeave:ke,onMouseUp:Ie,onDragLeave:De,onTouchEnd:Se,onTouchMove:Ne,onTouchStart:Fe,ref:Ue,tabIndex:p?-1:v,type:I},z,V,{children:[o,Pe?S.jsx(Ct,X({ref:xe,center:i},B)):null]}))}),St=Dt;export{St as B,G as T,re as _,at as a,H as b,Ze as c,ot as d,st as e,be as f,We as u};
